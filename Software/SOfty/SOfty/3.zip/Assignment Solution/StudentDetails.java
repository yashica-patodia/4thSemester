import javax.swing.*;

public class StudentDetails {
	JFrame f;

	StudentDetails() {
		f = new JFrame();
		JFrame f = new JFrame("Student Details");
		String data[][] = { { "19XY10001", "Sachin", "90" }, { "19XY10001", "Laxman", "85" }, { "19XY10001", "Rahul", "95" } };
		String column[] = { "Roll No.", "NAME", "Marks" };
		JTable jt = new JTable(data, column);
		jt.setBounds(30, 40, 200, 300);
		JScrollPane sp = new JScrollPane(jt);
		f.add(sp);
		f.setSize(300, 400);
		f.setVisible(true);
	}

	public static void main(String[] args) {
		new StudentDetails();
	}
}