import java.applet.Applet;
import java.awt.*;

/*
<applet code="AppletTest" width="250" height="200">
</applet> */
public class AppletTest extends Applet {
	public void paint(Graphics g) {
		g.setColor(Color.blue);
		g.drawRect(50, 80, 200, 150);
		g.setColor(Color.red);
		g.drawString("Welcome", 60, 100);
	}
}
