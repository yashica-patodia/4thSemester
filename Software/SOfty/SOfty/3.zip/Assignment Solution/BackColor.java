
/*
	Set Background Color Of an Applet Window Example 
	This java example shows how to set background color of an Applet window using
	setBackground method of component class.
*/
 
/*
<applet code="BackColor" width=200 height=200>
</applet>
*/
 
 
import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;
 
public class BackColor extends Applet{
 
	public void paint(Graphics g){
		/*
		 * Set background color of an applet using
		 * void setBackground(Color c) method.
		 */
		g.setColor(Color.blue);
		g.drawString("Hello World",10,25);
		setBackground(Color.green);
	}
}