import java.applet.*;
import java.awt.*;
import java.util.Date;

/*
<applet code="AppletThread" width="250" height="200">
</applet> */
public class AppletThread extends Applet implements Runnable {
	Thread t;
	Color c;
	int j = 0;

	public void start() {
		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}

	public void stop() {
		if (t != null) {
			t.stop();
			t = null;
		}
	}

	public void run() {
		while (true) {
			int i = (int) (6 * Math.random());
			j = i;
			switch (i) {
			case 1:
				this.c = Color.red;
				break;
			case 2:
				this.c = Color.green;
				break;
			case 3:
				this.c = Color.blue;
				break;
			case 4:
				this.c = Color.yellow;
				break;
			case 5:
				this.c = Color.orange;
				break;
			case 6:
				this.c = Color.magenta;
				break;
			default:
				this.c = Color.black;
				break;
			}
			repaint();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
			}
		}
	}

	public void paint(Graphics g) {
		g.setColor(c);
		g.drawString("This is an animation.", 10, 25);
	}
}
