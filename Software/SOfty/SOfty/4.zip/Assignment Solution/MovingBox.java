import java.applet.Applet;
import java.awt.*;

class ChooseColor extends Thread {

	MovingBox mb;
	boolean flag;

	public ChooseColor(MovingBox mb) {
		this.mb = mb;
		this.flag = false;
		this.start();
	}

	public void run() {
		while (true) {
			if (flag) {
				mb.c = Color.cyan;
				flag = false;
			} else {
				mb.c = Color.RED;
				flag = true;
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException ex) {
			}
		}
	}
}

public class MovingBox extends Applet implements Runnable {

	public Color c;
	ChooseColor cc;
	int h, w, x, y;
	int min, max;

	@Override
	public void init() {
		this.min = 10;
		this.max = this.getWidth() - 110;
		y = 40;
		x = 10;
		h = 60;
		w = 100;
		this.c = Color.RED;
		cc = new ChooseColor(this);
		new Thread(this).start();
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		Dimension d = getSize();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, d.width, d.height);
		g.setColor(c);
		g.fillRect(x, y, w, h);
		g.setColor(Color.black);
		g.drawString("<Your Name>", x + 10, y + 30);
	}

	@Override
	public void run() {
		while (true) {
			if (x < this.max || x < this.min)
				x++;
			else
				break;
			this.repaint();
			try {
				Thread.sleep(50);
			} catch (InterruptedException ex) {
			}
		}
	}
}
