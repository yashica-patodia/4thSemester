public class Bank{
	double threshold;
	double curr_amount;
	String name="";
	
	public Bank(int curr_amount, String name){
		this.threshold=3000;
		this.curr_amount=curr_amount;
		this.name=name;
	}
	
	public void debit(int amount)throws Exception{
		if(this.curr_amount<this.threshold){
			System.out.println(name+", Your remaining balance is Rs. "+(curr_amount-200)+"."); // Something extra: It is not part of the question
			throw new Exception("You Have to pay penalty of Rs. 200.");
		}else{
			System.out.println(name+", Your remaining balance is Rs. "+(curr_amount-amount)+".");
		}
	}
	
	public static void main(String[] args){
		Bank customer1=new Bank(2500, "Customer1");
		Bank customer2=new Bank(3500, "Customer2");
		try{
			customer1.debit(200);
			customer2.debit(200);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}