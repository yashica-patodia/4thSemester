import java.util.ArrayList;

public class ArrayListDemo {

    public static void main(String[] args) {
        // Create an empty ArrayList to hold integers
        ArrayList<Integer> list = new ArrayList<>();

        // Store the squares of the first 10 natural numbers
        for (int i = 1; i <= 10; i++) {
            list.add(i * i);
        }

        // Print the elements
        System.out.println("The list contains the following items:");

        for (int item : list) {
            System.out.println(item);
        }

        // Print the size of the list
        System.out.println("Size of the list is: " + list.size());

        // Empty the list
        list.clear();

        // Is the list empty?
        System.out.println("The list is empty: " + list.isEmpty());
    }
}