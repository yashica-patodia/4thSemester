import java.util.*;
class ArrayDemo
{
  public static void main(String args[])
  {

   Scanner sc=new Scanner(System.in);
   System.out.println("Enter Size of Array");
   int n=sc.nextInt();
   try
   {
     int[] arr=new int[n];
     for(int i=0;i<arr.length;i++)
     {
      System.out.println("enter "+i+" th element");
      arr[i]=sc.nextInt();
     }
     System.out.println("Elements of Array");
     for(int i=0;i<arr.length;i++)
     {
       System.out.println(arr[i]);
     }
   }
   catch(NegativeArraySizeException e)
   {
       System.out.println("Exception Caught: You have Given Negative Array Size");
   }
  
 }
}