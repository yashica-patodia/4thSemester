
public class Employee {
private String empID;
private String name;
private double salary;

public Employee(String empID, String name)
{
	this.empID=empID;
	this.name=name;
	this.salary=0;
}

public Employee(String empID, String name, double salary)
{
	this.empID=empID;
	this.name=name;
	this.salary=salary;
}

public String getEmpID() {
	return empID;
}


public String getName() {
	return name;
}

public double getSalary() {
	return salary;
}

public void setSalary(double salary) {
	this.salary = salary;
}
}
