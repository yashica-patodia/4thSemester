import java.util.ArrayList;

public class DataEntryNew {
	ArrayList<Employee> EmpList = new ArrayList<Employee>();
	Manager m1 = new Manager("M001", "A", Math.log(2 + 1) * 100000, 1);
	Manager m2 = new Manager("M002", "B", Math.log(2 + 2) * 100000, 2);
	Manager m3 = new Manager("M003", "C", Math.log(2 + 3) * 100000, 3);
	Manager m4 = new Manager("M004", "D", Math.log(2 + 4) * 100000, 4);
	Manager m5 = new Manager("M005", "E", Math.log(2 + 5) * 100000, 5);
	Programmer p1 = new Programmer("P001", "F", 30000, "Java", 1);
	Programmer p2 = new Programmer("P002", "G", 30000, "Python", 2);
	Programmer p3 = new Programmer("P003", "H", 30000, "Java", 3);
	Programmer p4 = new Programmer("P004", "I", 30000, "C", 4);
	Programmer p5 = new Programmer("P005", "J", 30000, "Java", 5);

	public void storeEmpRecord() {
		EmpList.add(m1);
		EmpList.add(m2);
		EmpList.add(m3);
		EmpList.add(m4);
		EmpList.add(m5);
		EmpList.add(p1);
		EmpList.add(p2);
		EmpList.add(p3);
		EmpList.add(p4);
		EmpList.add(p5);
	}

	public void displayEmpRecord() {
		for (Employee e : EmpList) {
			System.out.println("EmpID: " + e.getEmpID() + " Name: " + e.getName() + " Salary " + e.getSalary());
		}
	}

	public void incrementSalary() {
		ArrayList<Programmer> ProList = new ArrayList<Programmer>();
		ProList.add(p1);
		ProList.add(p2);
		ProList.add(p3);
		ProList.add(p4);
		ProList.add(p5);
		for (Programmer p : ProList) {
			if (p.getProgrammingLanguage().equals("Java")) {
				p.setSalary(p.getSalary() + 5000);
			}
		}
	}

	public static void main(String s[]) {
		DataEntryNew de = new DataEntryNew();
		de.storeEmpRecord();
		de.displayEmpRecord();
		de.incrementSalary();
		de.displayEmpRecord();
	}
}
