public class BoxPolymorf {

	public int area(int x, int y) {
		return x * y;
	}

	public double area(double x, double y) {
		return x * y;
	}

	public double area(int x, double y) {
		return x * y;
	}

	public int area(int x) {
		return x * x;
	}

	public double area(double x) {
		return x * x;
	}

	public static void main(String[] args) {
		BoxPolymorf rectangle = new BoxPolymorf();
		BoxPolymorf rectangle1 = new BoxPolymorf();
		BoxPolymorf rectangle2 = new BoxPolymorf();
		BoxPolymorf square = new BoxPolymorf();
		BoxPolymorf square1 = new BoxPolymorf();

		System.out.println("The area of a rectangle is " + rectangle.area(5, 10) + " sq. unit.");
		System.out.println("The area of a rectangle1 is " + rectangle1.area(5.5, 10.5) + " sq. unit.");
		System.out.println("The area of a rectangle2 is " + rectangle2.area(5, 10.5) + " sq. unit.");
		System.out.println("The area of a square is " + square.area(10) + " sq. unit.");
		System.out.println("The area of a square1 is " + square1.area(10.5) + " sq. unit.");
	}
}