class AttendanceException extends Exception {
}

public class Attendance {
	double percent;

	public void check() throws AttendanceException {
		if (percent < 40) {
			throw new AttendanceException();
		}
	}

	public static void main(String a[]) {
		Attendance a1 = new Attendance();
		Attendance a2 = new Attendance();
		Attendance a3 = new Attendance();
		a1.percent = 90;
		a2.percent = 56;
		a3.percent = 34;
		try {
			a1.check();
			a2.check();
			a3.check();
		} catch (AttendanceException ae) {
			System.out.println("Low Attendance");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("Attendance should be greater than 40%");
		}
	}
}
