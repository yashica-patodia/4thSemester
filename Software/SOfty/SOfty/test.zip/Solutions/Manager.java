
public class Manager extends Employee{
private int subordinateCount;

public Manager(String empID, String name, double salary, int subordinateCount)
{
	super(empID,name,salary);
	this.subordinateCount=subordinateCount;
}

public int getSubordinateCount() {
	return subordinateCount;
}

public void setSubordinateCount(int subordinateCount) {
	this.subordinateCount = subordinateCount;
}



}
