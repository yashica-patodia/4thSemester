class Animal {
	String eat() {
		return "";
	}
}

// Creating child classes.
class Dog extends Animal {

	String eat() {
		return "Meat";
	}
}

class Cat extends Animal {

	String eat() {
		return "Mouse";
	}
}

class Elephant extends Animal {

	String eat() {
		return "Grass";
	}
}

// Test class to create objects and call the methods
class ViewAnimals {
	public static void main(String args[]) {
		Dog d = new Dog();
		Cat c = new Cat();
		Elephant e = new Elephant();
		System.out.println("Dog eats: " + d.eat());
		System.out.println("Cat eats: " + c.eat());
		System.out.println("Elephant eats: " + e.eat());
	}
}