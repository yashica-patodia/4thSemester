
public class Programmer extends Employee{
private String programmingLanguage;
private int experienceInYears;

public Programmer(String empID, String name, double salary, String programmingLanguage, int experienceInYears)
{
	super(empID,name,salary);
	this.programmingLanguage=programmingLanguage;
	this.experienceInYears=experienceInYears;
}

public String getProgrammingLanguage() {
	return programmingLanguage;
}

public void setProgrammingLanguage(String programmingLanguage) {
	this.programmingLanguage = programmingLanguage;
}

public int getExperienceInYears() {
	return experienceInYears;
}

public void setExperienceInYears(int experienceInYears) {
	this.experienceInYears = experienceInYears;
}

}
